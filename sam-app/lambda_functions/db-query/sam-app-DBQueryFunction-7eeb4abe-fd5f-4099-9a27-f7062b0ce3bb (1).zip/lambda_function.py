"""
Lambda function to handle API requests for getting values
from DynamoDB
Note: this function is setup to handle all tables and both
queries and scanning.

Location of Query parameters configurable through 'resourceLocation' variable




@Author: Jeff Johansen (johajeff@), Edmund Chute (chuteec@)

"""
import json
import boto3
import os
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError, ParamValidationError

dynamodb = boto3.resource('dynamodb')
resourceLocation='headers'


"""Lambda Base Function"""
def lambda_handler(event, context):

	print(event)
		
	# get name of table from API request and remove from inputs
	table_name = str(event[resourceLocation]['table_name'])
	print(table_name)
	print("Grabbing TableName")
	del event[resourceLocation]['table_name']
	print("Deleting TableName")
	table_client = dynamodb.Table(table_name)
	table_desc = boto3.client('dynamodb').describe_table(TableName = table_name)
	
	print(len(event[resourceLocation]))
	
	
	data = []
	response = {}

	if event['httpMethod'] == "GET":
		try:
			p_key = None
			s_key = None
			for key in table_desc['Table']['KeySchema']:
				if key['KeyType'] == 'HASH':
					p_key = key['AttributeName']
				else:
					s_key = key['AttributeName']
			using_gsi = False
			if 'index_name' in event[resourceLocation]:
				using_gsi = True
				print("in index name")
				indx_name = event[resourceLocation]['index_name']
				del event[resourceLocation]['index_name']
				found_gsi = False
				for gsi in table_desc['Table']['GlobalSecondaryIndexes']:
					if gsi['IndexName'] == indx_name:
						found_gsi = True
						for key in gsi['KeySchema']:
							if key['KeyType'] == 'HASH':
								p_key = key['AttributeName']
							else:
								s_key = key['AttributeName']
				if not found_gsi:
					return {
						"statusCode": 400,
						"body": json.dumps({"ErrorMSG":"Invalid Index_Name"}),
						"headers":{
							"Access-Control-Allow-Origin":"*",
							"Access-Control-Allow-Credentials" : "true",
							"Access-Control-Allow-Headers":'predictor_name_type,predictee_name_type,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code',

						}
					}
					
			# do plain scan if we have no primary key
			if p_key not in event[resourceLocation]:
				# additional parameters can be found in the event[resourceLocation]
				filter_str = ""
				is_first = True
				attr_vals = {}
				for (key, value) in event[resourceLocation].items():
					if key.lower() in UseHeader:
						attr_vals[":" + str(key)] = str(value)
						if is_first:
							filter_str = filter_str + str(str(key) + "=:" + str(key))
							is_first = False
						else:
							filter_str = filter_str + str(" AND " + str(key) + "=:" + str(key))
				print("Filter String: " + filter_str)
				print(attr_vals)
				

				# no filters if there are no more input parameters
				if not using_gsi:
					if filter_str == "":
						response = table_client.scan()
						data = response['Items']
						# continue retrieving values until all retrieved
						while 'LastEvaluatedKey' in response:
							response = table_client.scan()
							data.extend(response['Items'])
					else:
						response = table_client.scan(
							FilterExpression = filter_str,
							ExpressionAttributeValues= attr_vals)
						data = response['Items']
						# continue retrieving values until all retrieved
						while 'LastEvaluatedKey' in response:
							response = table_client.scan(
							FilterExpression = filter_str,
							ExpressionAttributeValues= attr_vals)
							data.extend(response['Items'])
				else:
					if filter_str == "":
						response = table_client.scan(IndexName = indx_name)
						data = response['Items']
						# continue retrieving values until all retrieved
						while 'LastEvaluatedKey' in response:
							response = table_client.scan(IndexName = indx_name)
							data.extend(response['Items'])
					else:
						response = table_client.scan(
							IndexName = indx_name,
							FilterExpression = filter_str,
							ExpressionAttributeValues= attr_vals)
						data = remove['Items']
						while 'LastEvaluatedKey' in response:
							response = table_client.scan(
							IndexName = indx_name,
							FilterExpression = filter_str,
							ExpressionAttributeValues= attr_vals)
							data.extend(response['Items'])
					

			# otherwise query the table based on inputs
			# we know that we have the primary key passed in (maybe secondary too)
			else:
				attr_vals = {}
				query_str = ""
				filter_str = ""
				
				# construct query string and attribute values out of keys
				# avoid adding AND at beginning of query string
				is_first = True
				is_first_filter = True
				for (key, value) in event[resourceLocation].items():
					if key.lower() in UseHeader:
						attr_vals[":" + str(key)] = str(value)
						if key == p_key or key == s_key:
							if is_first:
								query_str = query_str + str(key + "=:" + key)
								is_first = False
							else:
								query_str = query_str + str(" AND " + key + "=:" + key)
						else:
							if is_first_filter:
								filter_str = filter_str + str(key + "=:" + key)
								is_first_filter = False
							else:
								filter_str = filter_str + str(" AND " + key + "=:" + key)
				
				# Delete used Keys from queryStringParameters			
				if p_key in event[resourceLocation]:
					del event[resourceLocation][p_key]
				if s_key in event[resourceLocation]:
					del event[resourceLocation][s_key]
					
				# run query without filters
				if filter_str=="":
					# querying without a GSI
					if not using_gsi:
						response = table_client.query(
							KeyConditionExpression= query_str,
							ExpressionAttributeValues= attr_vals          
						)
						
						
						data = response['Items']
						while 'LastEvaluatedKey' in response:
							response = table_client.query(
								ExclusiveStartKey=response['LastEvaluatedKey'],
								KeyConditionExpression= query_str,
								ExpressionAttributeValues= attr_vals           
							)
							data.extend(response['Items'])
							
					# querying with a GSI
					else:
						response = table_client.query(
							KeyConditionExpression= query_str,
							ExpressionAttributeValues= attr_vals,
							IndexName = indx_name
						)
						
						data = response['Items']
						
						while 'LastEvaluatedKey' in response:
							response = table_client.query(
								ExclusiveStartKey=response['LastEvaluatedKey'],
								KeyConditionExpression= query_str,
								ExpressionAttributeValues= attr_vals,
								IndexName = indx_name
							)
							data.extend(response['Items'])
				else:
					# querying without a GSI
					if not using_gsi:
						response = table_client.query(
							KeyConditionExpression= query_str,
							ExpressionAttributeValues= attr_vals, 
							FilterExpression = filter_str        
						)
						
						data = response['Items']
						
						while 'LastEvaluatedKey' in response:
							response = table_client.query(
								ExclusiveStartKey=response['LastEvaluatedKey'],
								KeyConditionExpression= query_str,
								ExpressionAttributeValues= attr_vals,
								FilterExpression = filter_str          
							)
							data.extend(response['Items'])
							
					# querying with a GSI
					else:
						response = table_client.query(
							KeyConditionExpression= query_str,
							ExpressionAttributeValues= attr_vals,
							IndexName = indx_name,
							FilterExpression = filter_str
						)
						
						data = response['Items']
						
						while 'LastEvaluatedKey' in response:
							response = table_client.query(
								ExclusiveStartKey=response['LastEvaluatedKey'],
								KeyConditionExpression= query_str,
								ExpressionAttributeValues= attr_vals,
								IndexName = indx_name,
								FilterExpression = filter_str
							)
							data.extend(response['Items'])
		except ClientError or ParamValidationError as error:
			print(error)
			return {
				"statusCode": 400,
				"body": json.dumps(error.response['Error']),
				"headers":{
					"Access-Control-Allow-Origin":"*",
					"Access-Control-Allow-Credentials" : "true",
					"Access-Control-Allow-Headers":'predictor_name_type,predictee_name_type,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code',

				}
			}	
	else:
		returnDeadEnd()
	
	print(data)
	
	return {
		"statusCode": 200,
		"body": json.dumps(data),
		"headers":{
					"Access-Control-Allow-Origin":"*",
					"Access-Control-Allow-Credentials" : "true",
					"Access-Control-Allow-Headers":'predictor_name_type,predictee_name_type,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code',
		}
	}


def returnDeadEnd():
	return{
		"statusCode": 400,
		"body": json.dumps({
			"message": "Request method not supported"
		}),
		"headers":{
					"Access-Control-Allow-Origin":"*",
					"Access-Control-Allow-Credentials" : "true",
					"Access-Control-Allow-Headers":'predictor_name_type,predictee_name_type,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code',

		}
	}

UseHeader = {
	"table_name",
	"index_name",
	"offering_name",
	"offering_type",
	"caf_perspective",
	"capability",
	"gsp_vertical",
	"id_num",
	"offering_description",
	"offering_maturity_level",
	"owner",
	"practice_group",
	"wiki_link",
	"delivery_kit",
	"sales_kit",
	"customer_name",
	"product_name",
	"close_date",
	"list_price",
	"list_price_currency",
	"owner_name",
	"practice_lookup-practice_name",
	"quantity",
	"stage",
	"total_opportunity",
	"total_opportunity_currency",
	"product_code",
	"predictee_name_type",
	"predictor_name_type"
}
