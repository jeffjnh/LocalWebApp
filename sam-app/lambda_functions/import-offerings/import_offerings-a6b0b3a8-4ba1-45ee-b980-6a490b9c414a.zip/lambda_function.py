"""
Lambda function to upload .CSV extended files into a DynamoDB table
@Author: Edmund Chute (chuteec@), Jeff Johansen(johajeff@)
"""

import boto3
import urllib
import csv
import json
import decimal

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
table_name = "OfferingSales"
  
#Temporary product_name dictionary
project_map = {}

def lambda_handler(event, context):
    record = event['Records'][0]
    bucket_name = record['s3']['bucket']['name']
    key = record['s3']['object']['key']
    raw_key = urllib.parse.unquote_plus(key)
    download_path = '/tmp/{}'.format(key)
    
    s3_client.download_file(bucket_name, raw_key, download_path)

    table = dynamodb.Table(table_name)
    
    with open(download_path, newline='') as csvfile:
        csv_reader = csv.reader(csvfile, delimiter=',', quotechar='"')
        get_title = True
        keys = []
        count = 0
        with table.batch_writer() as batch:
            for row in csv_reader:
                count = count + 1
                if get_title:
                    for key in row:
                        keys.append(key.lower())
                    get_title = False
                else:
                    entries = {}
                    for indx, entry in enumerate(row, start=0):
                        if entry != "":
                            entries[keys[indx]] = entry
                        
                    if str(entries['customer_name']  + entries['product_name']) not in project_map:
                        project_map[str(entries['customer_name']  + entries['product_name'])] = 0
                    else:
                        project_map[str(entries['customer_name']  + entries['product_name'])] = project_map[str(entries['customer_name']  + entries['product_name'])] + 1
                        entries['product_name'] = entries['product_name'] + "-" + str(project_map[str(entries['customer_name']  + entries['product_name'])])
                      
                    
                    batch.put_item(Item=entries)
                
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully wrote CSV to DynamoDB.')
    }