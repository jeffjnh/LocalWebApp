"""
Lambda function to handle API requests for taking in salesforce
data, mapping it to existing offerings, and returning suggested
offerings for that customer.

@Authors: Jeff Johansen (johajeff@), Edmund Chute (chuteec@)

"""
import boto3
import json
# import numpy as np
import os
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError, ParamValidationError
import re

"""
This function expects:
	- SalesForce rows as input data 
It transforms this data by:
	- Matching each Sale to a corresponding offering within the proserv offerings portfolio 
	- Returning recommended next steps for offering sales
	- Returning matched offerings for direct comparison between SF data and aligned offering	
"""


#Offering_Type ordering for prediction model. 1-2-3-4 represent standard 4 offering types, 100-200-300 cases not handled
align_scale = { 
	'Align Offering':1, 
	'Launch Offering':2, 
	'Scale Offering':3, 
	'Optimize Offering':4,
	'Foundation Launch':100,
	'DK':200,
	'SK':300,
	'DK Only':400,
	'SK Only':500,
	'TBD':600,
}

#Blacklist of prepositions not used in string compare as they will falsely imbalance the comparison
blackList={
	"is",
	"it",
	"the",
	"and",
	"&",
	"or",
	"aws",
	"for",
	"@",
	"in",
	"on",
	None
}

#Global Vars
dynamodb = boto3.resource('dynamodb')
resourceLocation='headers' #Dependent on HTTP request type, currently stored in 'headers', could be 'body', 'queryStringParams', etc...
minWeight = 0.333


"""JJStringCompare algorithm for cross-GSP prediction model"""
def stringInterpolator(current, sugg):
	current = current['offering_name'].lower()
	sugg = sugg['offering_name'].lower()
	mCurrentSet = set(re.split("//|@|&| |-|_|/(|/)|, ", current)).difference(blackList)
	mSuggestionSet = set(re.split("//|@|&| |-|_|/(|/)|, ", sugg)).difference(blackList)
	
	sameSet = mCurrentSet.intersection(mSuggestionSet)
	
	# print(sameSet)
	
	var = len(sameSet) / ((len(mCurrentSet) + len(mSuggestionSet)) / 2)
	# print(var)
	if var >= minWeight:
		return True
	return False
	


"""Prediction model executor"""
def does_predict(current, to_suggest):
	
	offering_level_difference = align_scale[to_suggest['offering_type']] - align_scale[current['offering_type']]
	
	if int(to_suggest['offering_maturity_level']) < 2:
		return False
	elif current["gsp_vertical"] == to_suggest["gsp_vertical"]:
		if offering_level_difference >= 0 and offering_level_difference < 2:
			return True
	elif offering_level_difference >= 0 and offering_level_difference < 2 and current['offering_name'] != to_suggest["offering_name"]:
		return stringInterpolator(current, to_suggest)
	return False


def lambda_handler(event, context):

		
	# Global data object, constants and basic references
	offerings_table_name = "Offerings"
	sales_table_name = "OfferingSales"
	predictions_table_name = "OfferingPredictions"
	predictions_table_client = dynamodb.Table(predictions_table_name)
	offerings_table_client = dynamodb.Table(offerings_table_name)
	sales_table_client = dynamodb.Table(sales_table_name)
	offerings_table_desc = boto3.client('dynamodb').describe_table(TableName = offerings_table_name)
	sales_table_desc = boto3.client('dynamodb').describe_table(TableName = sales_table_name)
	matches = []
	all_suggestions = []
	predicted_by = {}
	offerings_names = {} 
	response_body = {}
	
	
	try:
		#Grab all data
		sales_entries = json.loads(event['headers']['sales'])
		print(sales_entries)
		full_table = offerings_table_client.scan()# list of all the offerings
		offerings_data = full_table['Items']
		for offering in offerings_data: #Trim down to all offering_name's
			offerings_names[offering['offering_name'].lower().replace("&", "and")] = offering
		for entry in sales_entries: #Search for matches to other offerings
			prod_name = entry['product_name'].lower().replace("&","and")
			search_offering_names = prod_name.split(' - ')
			search_offering_name = search_offering_names[-1]
			# print( search_offering_name )
			if search_offering_name in offerings_names:
				matches.append(offerings_names[search_offering_name])
			else:
				matches.append({})
		print("matches: ")
		print(matches)
		indx = 0
		for match in matches: #Find recommendations
			if match != {}:
				# match_suggestions = []
				for offering in offerings_data:
					if does_predict(match, offering):
						if frozenset(offering.items()) in predicted_by:
							predicted_by[frozenset(offering.items())].append(indx)
						else:
							predicted_by[frozenset(offering.items())] = [indx]
				
				 
				# Pull Matches from Dynamo Predictions Table
				attrvals = {}
				attrvals[":val"] = str(match['offering_name']+"|"+match['offering_type'])
				user_recs = predictions_table_client.query(
					KeyConditionExpression=("predictor_name_type =:val" ),							
					ExpressionAttributeValues=attrvals,   
				)['Items']
				
				print(attrvals)
				user_predictions = []
				
				for rec in user_recs:
					user_predictions.append(rec["predictee_name_type"])
				
				
				# print( "grabbedPredictions" + str(user_predictions))
				user_pred_full_offerings = []
				for offering in offerings_data:
					jointstr = str(offering['offering_name']+"|"+offering["offering_type"])
					if jointstr in user_predictions:
						user_pred_full_offerings.append(offering)
						
				for matchedOffering in user_pred_full_offerings:
					if frozenset(matchedOffering.items()) in predicted_by:
						predicted_by[frozenset(matchedOffering.items())].append(indx)
					else:
						predicted_by[frozenset(matchedOffering.items())] = [indx]
						
			indx += 1
		for prediction, pred_lst in predicted_by.items():
			dict_pred = dict(prediction)
			dict_pred["salesIndices"] = pred_lst
			all_suggestions.append(dict_pred)

		print(all_suggestions)
			
	except ClientError or ParamValidationError as error: #If any dynamoDB error occurs, the error message will be returned for easier debugging
		return {
			"statusCode": 400,
			"body": json.dumps(error.response['Error']),
			"headers":{
				"Access-Control-Allow-Origin":"*",
				"Access-Control-Allow-Credentials" : "true",
				"Access-Control-Allow-Headers":'sales,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code,Access-Control-Allow-Origin,access-control-allow-origin,Access-Control-Allow-Headers,access-control-allow-headers'

			}
		}	


	#Build JSON response_body for return JSON payload
	response_body['matches'] = matches
	response_body['suggestions'] = all_suggestions
 
 
	print("Bingo.")


	"""Positive Return Ending, dumps response body data to JSON"""
	return {
		"statusCode": 200,
		"body": json.dumps(response_body),
		"headers":{
					"Access-Control-Allow-Origin":"*",
					"Access-Control-Allow-Credentials" : "true",
					"Access-Control-Allow-Headers":'sales,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,xyz,table_name,index_name,offering_name,offering_type,caf_perspective,capability,gsp_vertical,id_num,offering_description,offering_maturity_level,owner,practice_group,wiki_link,delivery_kit,sales_kit,customer_name,product_name,close_date,list_price,list_price_currency,owner_name,practice_lookup-practice_name,quantity,stage,total_opportunity,total_opportunity_currency,product_code,Access-Control-Allow-Origin,access-control-allow-origin,Access-Control-Allow-Headers,access-control-allow-headers'
		}
	}