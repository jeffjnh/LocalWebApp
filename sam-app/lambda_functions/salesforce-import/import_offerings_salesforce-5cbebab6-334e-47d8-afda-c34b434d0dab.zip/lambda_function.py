"""
Lambda Function To import data from SalesForce (ProservePortfolio non-generic) to
a DynamoDB table. Used to discern multiple lines with similar signatures.

@Author: Jeff Johanse (johajeff@), Edmund Chute (chuteec@)
"""

import boto3
import urllib
import csv
import json
import decimal

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
table_name = "Offerings"

def lambda_handler(event, context):
    record = event['Records'][0]
    bucket_name = record['s3']['bucket']['name']
    key = record['s3']['object']['key']
    raw_key = urllib.parse.unquote_plus(key)
    download_path = '/tmp/{}'.format(key)
    
    s3_client.download_file(bucket_name, raw_key, download_path)

    table = dynamodb.Table(table_name)
    
    with open(download_path, newline='') as csvfile:
        csv_reader = csv.reader(csvfile, delimiter=',', quotechar='"')
        get_title = True
        keys = []
        count = 0
        with table.batch_writer() as batch:
            for row in csv_reader:
                count = count + 1
                if get_title:
                    for key in row:
                        keys.append(key.lower())
                    get_title = False
                else:
                    entries = {}
                    for indx, entry in enumerate(row, start=0):
                        if entry != "":
                            entries[keys[indx]] = entry
                    entries['id_num'] = str(count - 1)
                    batch.put_item(Item=entries)
                
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully wrote CSV to DynamoDB.')
    }